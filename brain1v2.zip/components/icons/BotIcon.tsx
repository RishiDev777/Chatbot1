
import React from 'react';

export const BotIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg 
    xmlns="http://www.w3.org/2000/svg" 
    viewBox="0 0 20 20" 
    fill="currentColor" 
    {...props}
  >
    <path d="M10 3.5A1.5 1.5 0 0111.5 5v1.5A1.5 1.5 0 0110 8a1.5 1.5 0 01-1.5-1.5V5A1.5 1.5 0 0110 3.5z" />
    <path 
      fillRule="evenodd" 
      d="M5.22 10.097a3.501 3.501 0 000 4.806l.001.002A1.5 1.5 0 014 16.5V13a1 1 0 00-1-1H1.5a1.5 1.5 0 01-.098-2.993l.002-.001.002-.001A3.501 3.501 0 005.22 10.097zM14.78 10.097a3.501 3.501 0 010 4.806l-.001.002A1.5 1.5 0 0016 16.5V13a1 1 0 011-1h1.5a1.5 1.5 0 00.098-2.993l-.002-.001-.002-.001A3.501 3.501 0 0114.78 10.097z" 
      clipRule="evenodd" 
    />
    <path d="M10 18a8 8 0 100-16 8 8 0 000 16zm0-2a6 6 0 100-12 6 6 0 000 12z" />
  </svg>
);
