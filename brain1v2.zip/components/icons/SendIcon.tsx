
import React from 'react';

export const SendIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 20 20"
    fill="currentColor"
    {...props}
  >
    <path d="M3.105 3.105a1.5 1.5 0 012.122-.001L19.14 10.173a1.497 1.497 0 010 2.307L5.227 19.547a1.5 1.5 0 01-2.122-2.122L14.878 11.35 3.105 5.227a1.5 1.5 0 010-2.122z" />
  </svg>
);
