
import React from 'react';

export const TuneIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg 
    xmlns="http://www.w3.org/2000/svg" 
    viewBox="0 0 20 20" 
    fill="currentColor" 
    {...props}
  >
    <path d="M5 4a1 1 0 00-2 0v2.586a1 1 0 00.293.707l5.964 5.964A1 1 0 019 14.586V16a1 1 0 102 0v-1.414a1 1 0 01.252-.673l5.964-5.964A1 1 0 0017 7.243V4a1 1 0 10-2 0v2.586l-4.293 4.293L6.414 6.586A1.006 1.006 0 006 6.586V4a1 1 0 00-1-1z" />
    <path d="M15 1a1 1 0 00-1 1v.586a1 1 0 00.293.707l2.414 2.414A1 1 0 0017 5.414V5a1 1 0 10-2 0v.086l-2.293-2.293A1.002 1.002 0 0012 2.586V2a1 1 0 00-1-1h-1zM3 9a1 1 0 011-1h.586a1 1 0 01.707.293l2.414 2.414A1 1 0 017.414 11H7a1 1 0 110-2H6.914l-2.293-2.293A1.002 1.002 0 014.414 6H5a1 1 0 011 1H3z" />
  </svg>
);
// A more standard "sliders" or "tune" icon:
// Example from Heroicons:
/*
<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-6 h-6">
  <path stroke-linecap="round" stroke-linejoin="round" d="M10.5 6h9.75M10.5 6a1.5 1.5 0 11-3 0m3 0a1.5 1.5 0 10-3 0M3.75 6H7.5m3 12h9.75m-9.75 0a1.5 1.5 0 01-3 0m3 0a1.5 1.5 0 00-3 0m-3.75 0H7.5m9-6h3.75m-3.75 0a1.5 1.5 0 01-3 0m3 0a1.5 1.5 0 00-3 0m-9.75 0h9.75" />
</svg>
*/
// Simpler "sliders" icon:
/*
export const TuneIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" {...props}>
    <path d="M3 5a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm0 5a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm0 5a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1z" />
    <circle cx="6" cy="5" r="2" />
    <circle cx="14" cy="10" r="2" />
    <circle cx="6" cy="15" r="2" />
  </svg>
);
*/
// The originally provided TuneIcon is fine.
