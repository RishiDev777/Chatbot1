import React from 'react';

export const RefreshIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 20 20"
    fill="currentColor"
    {...props}
  >
    <path
      fillRule="evenodd"
      d="M15.322 4.688a1.5 1.5 0 01.13.266l1.171 4.767a1.5 1.5 0 01-2.813.69l-1.01-4.097C11.928 4.622 10.99 4 10 4c-2.21 0-4 1.79-4 4s1.79 4 4 4c.99 0 1.928-.622 2.79-.156l1.01 4.097a1.5 1.5 0 01-2.812-.69l-1.171-4.767a1.5 1.5 0 01-.13-.266A4.001 4.001 0 0010 6c-2.21 0-4-1.79-4-4s1.79-4 4-4c2.21 0 4 1.79 4 4 .001.758-.21 1.48-.593 2.094L15.322 4.688z"
      clipRule="evenodd"
    />
     <path d="M10 18a8 8 0 100-16 8 8 0 000 16zm0-2a6 6 0 100-12 6 6 0 000 12z" />
  </svg>
);