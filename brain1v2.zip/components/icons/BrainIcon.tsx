import React from 'react';

export const BrainIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg 
    xmlns="http://www.w3.org/2000/svg" 
    viewBox="0 0 24 24" 
    fill="none" 
    stroke="currentColor" 
    strokeWidth="1.5"
    strokeLinecap="round" 
    strokeLinejoin="round" 
    {...props}
  >
    <style>
      {`
        @keyframes rotateOrbitalPath {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
        .orbital-path-animate {
          animation: rotateOrbitalPath 20s linear infinite;
          transform-origin: center;
        }
        @keyframes rotateSatellites {
          from { transform: rotate(0deg); }
          to { transform: rotate(-360deg); } /* Rotate opposite direction or same */
        }
        .satellites-group-animate {
          animation: rotateSatellites 25s linear infinite; /* Slightly different speed */
          transform-origin: center;
        }
        @keyframes pulseCenterOrb {
           0%, 100% { r: 5.8; opacity: 0.9; }
           50% { r: 6.2; opacity: 1; }
        }
        .center-orb-animate {
          animation: pulseCenterOrb 3s ease-in-out infinite;
        }
      `}
    </style>
    
    {/* Central Orb - subtle pulse */}
    <circle cx="12" cy="12" r="6" className="center-orb-animate" />

    {/* Orbital Path - rotating */}
    <path d="M6,12 a6,6 0 1,0 12,0 a6,6 0 1,0 -12,0" strokeDasharray="3 3" opacity="0.3" strokeWidth="1" className="orbital-path-animate"/>

    {/* Group for Satellite Orbs to rotate them together */}
    <g className="satellites-group-animate">
      <circle cx="6" cy="6" r="1.5" />
      <circle cx="18" cy="6" r="1.5" />
      <circle cx="18" cy="18" r="1.5" />
      <circle cx="6" cy="18" r="1.5" />
    </g>
  </svg>
);