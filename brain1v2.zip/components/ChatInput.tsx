import React, { useState, useEffect } from 'react';
import { SendIcon } from './icons/SendIcon';
import { StopIcon } from './icons/StopIcon'; // New icon

export interface EditState {
  messageId: string;
  currentText: string;
}

interface ChatInputProps {
  onSendMessage: (message: string) => void;
  isLoading: boolean; // True when AI is responding
  onStopGenerating?: () => void; // Optional: Handler for stopping generation
  editingState: EditState | null;
  onCancelEdit: () => void;
}

export const ChatInput: React.FC<ChatInputProps> = ({ 
  onSendMessage, 
  isLoading, 
  onStopGenerating,
  editingState,
  onCancelEdit
}) => {
  const [inputText, setInputText] = useState('');

  useEffect(() => {
    if (editingState) {
      setInputText(editingState.currentText);
    } else {
      // If not editing, clear input *unless* it was just cleared by a successful send
      // This prevents clearing if user types then clicks cancel edit
      // setInputText(''); // This might be too aggressive, let user manage input unless submitting.
    }
  }, [editingState]);

  const handleSubmit = (e?: React.FormEvent<HTMLFormElement>) => {
    e?.preventDefault();
    if (!inputText.trim()) return; // Do not send if loading, App.tsx handles this check too.
    onSendMessage(inputText);
    if (!editingState) { // Only clear input if not in edit mode (edit mode submit is handled by App.tsx)
      setInputText('');
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      // Do not submit if AI is responding (isLoading) to prevent double sends or conflicts.
      // The App.tsx's handleSendOrUpdateMessage also has a guard for isAiResponding.
      if (!isLoading) {
          handleSubmit();
      }
    }
  };

  const isSendButtonDisabled = isLoading || !inputText.trim();
  const isStopButtonDisabled = !isLoading;

  return (
    <form onSubmit={handleSubmit} className="flex flex-col space-y-2">
      <div className="flex items-end space-x-2 sm:space-x-3">
        <textarea
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          onKeyPress={handleKeyPress}
          placeholder={editingState ? "Edit your message..." : "Message Brain1..."}
          rows={1}
          className="flex-grow p-3 bg-slate-800 text-slate-100 border border-slate-700 rounded-lg focus:ring-2 focus:ring-sky-500 focus:border-sky-500 resize-none scrollbar-thin scrollbar-thumb-sky-600 scrollbar-track-slate-800 max-h-[120px] min-h-[48px] transition-all duration-150"
          disabled={isLoading && !editingState} // Allow editing text even if AI is responding to something else
        />
        {isLoading && onStopGenerating && !editingState && (
           <button
            type="button"
            onClick={onStopGenerating}
            disabled={isStopButtonDisabled}
            className="p-3 bg-red-600 text-white rounded-lg hover:bg-red-500 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-opacity-75 disabled:opacity-60 disabled:cursor-not-allowed transition-all duration-150 h-[48px] w-[48px] flex items-center justify-center flex-shrink-0 active:scale-95 enabled:hover:scale-105 enabled:focus:scale-105"
            aria-label="Stop generating response"
          >
            <StopIcon className="w-5 h-5" />
          </button>
        )}
        {(!isLoading || editingState) && ( // Show Send/Save button if not loading OR if editing
          <button
            type="submit"
            disabled={isSendButtonDisabled && !editingState} // disable if loading AND not editing or no text
            className={`p-3 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-opacity-75 disabled:opacity-60 disabled:cursor-not-allowed transition-all duration-150 h-[48px] w-[48px] flex items-center justify-center flex-shrink-0 active:scale-95 enabled:hover:scale-105 enabled:focus:scale-105 ${
              editingState ? 'bg-green-600 hover:bg-green-500 focus:ring-green-500' : 'bg-sky-600 hover:bg-sky-500 focus:ring-sky-500'
            }`}
            aria-label={editingState ? "Save and submit message" : "Send message"}
          >
            {/* Using SendIcon for both Send and Save & Submit for simplicity, could use a SaveIcon */}
            <SendIcon className="w-6 h-6" />
          </button>
        )}
      </div>
      {editingState && (
        <div className="flex justify-end space-x-2 animate-fadeInSlideUp" style={{animationDuration: '0.2s'}}>
          <button
            type="button"
            onClick={onCancelEdit}
            className="px-3 py-1.5 text-sm bg-slate-600 hover:bg-slate-500 text-slate-100 rounded-md transition-colors duration-150 focus:outline-none focus:ring-2 focus:ring-slate-400"
            aria-label="Cancel edit"
          >
            Cancel
          </button>
        </div>
      )}
    </form>
  );
};