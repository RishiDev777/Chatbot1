
import React from 'react';
import { ChatSession } from '../types';
import { ConversationItem } from './ConversationItem';
import { PlusIcon } from './icons/PlusIcon';
import { BrainIcon } from './icons/BrainIcon'; // For branding in sidebar header

interface SidebarProps {
  sessions: ChatSession[];
  currentSessionId: string | null;
  onNewChat: () => void;
  onSelectChat: (sessionId: string) => void;
  onDeleteChat: (sessionId: string) => void;
  isOpen: boolean;
  toggleSidebar: () => void; // Not used directly here, but could be for a close button inside
}

export const Sidebar: React.FC<SidebarProps> = ({
  sessions,
  currentSessionId,
  onNewChat,
  onSelectChat,
  onDeleteChat,
  isOpen,
}) => {
  const sortedSessions = [...sessions].sort((a, b) => new Date(b.lastUpdatedAt).getTime() - new Date(a.lastUpdatedAt).getTime());

  return (
    <div
      className={`fixed inset-y-0 left-0 z-30 flex flex-col w-72 bg-slate-950 border-r border-slate-800 transform transition-transform duration-300 ease-in-out ${
        isOpen ? 'translate-x-0' : '-translate-x-full'
      } md:translate-x-0 md:static md:inset-y-auto md:flex`} // On md screens, it's static
    >
      <div className="p-4 border-b border-slate-800">
        <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-2">
                 <BrainIcon className="w-7 h-7 text-sky-400" />
                 <h2 className="text-xl font-semibold text-sky-400">Brain1 Chats</h2>
            </div>
        </div>
        <button
          onClick={onNewChat}
          className="w-full flex items-center justify-center space-x-2 px-4 py-2.5 bg-sky-600 text-white rounded-lg hover:bg-sky-500 focus:outline-none focus:ring-2 focus:ring-sky-500 focus:ring-opacity-75 transition-colors duration-150 animate-buttonPop"
          aria-label="Start a new chat"
        >
          <PlusIcon className="w-5 h-5" />
          <span>New Chat</span>
        </button>
      </div>

      <nav className="flex-grow p-3 space-y-1.5 overflow-y-auto scrollbar-thin scrollbar-thumb-sky-600 scrollbar-track-slate-950">
        {sortedSessions.map(session => (
          <ConversationItem
            key={session.id}
            session={session}
            isSelected={session.id === currentSessionId}
            onSelect={() => onSelectChat(session.id)}
            onDelete={() => onDeleteChat(session.id)}
          />
        ))}
        {sortedSessions.length === 0 && (
            <p className="text-sm text-slate-500 text-center py-4">No chats yet. Start a new one!</p>
        )}
      </nav>
      
      <div className="p-3 border-t border-slate-800 text-center">
        <p className="text-xs text-slate-500">&copy; Brain1 {new Date().getFullYear()}</p>
      </div>
    </div>
  );
};
