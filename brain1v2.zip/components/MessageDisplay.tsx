
import React, { useState, useEffect } from 'react';
import { ChatMessage, MessageSender } from '../types';
import { UserIcon } from './icons/UserIcon';
import { BrainIcon } from './icons/BrainIcon'; 
import { CopyIcon } from './icons/CopyIcon';
import { CheckIcon } from './icons/CheckIcon';
import { RefreshIcon } from './icons/RefreshIcon';
import { PencilIcon } from './icons/PencilIcon';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';

interface MessageDisplayProps {
  message: ChatMessage;
  isLastMessage: boolean;
  onRegenerate: () => void;
  onEdit: () => void;
  isAiResponding: boolean;
}

const markdownComponents: any = { 
  h1: ({node, ...props}) => <h1 className="text-2xl font-semibold my-3 text-sky-400" {...props} />,
  h2: ({node, ...props}) => <h2 className="text-xl font-semibold my-2.5 text-sky-400" {...props} />,
  h3: ({node, ...props}) => <h3 className="text-lg font-semibold my-2 text-sky-400" {...props} />,
  p: ({node, ...props}) => <p className="my-1.5 text-slate-200" {...props} />,
  ul: ({node, ...props}) => <ul className="list-disc list-inside my-2 pl-4 space-y-1 text-slate-300" {...props} />,
  ol: ({node, ...props}) => <ol className="list-decimal list-inside my-2 pl-4 space-y-1 text-slate-300" {...props} />,
  li: ({node, ...props}) => <li className="mb-0.5" {...props} />,
  blockquote: ({node, ...props}) => <blockquote className="border-l-4 border-sky-500 pl-3 italic my-2 text-slate-300" {...props} />,
  code: ({ node, inline, className, children, ...props }) => {
    const match = /language-(\w+)/.exec(className || '');
    return !inline ? (
      <pre className="bg-slate-950 p-3 rounded-md overflow-x-auto my-2 scrollbar-thin scrollbar-thumb-sky-600 scrollbar-track-slate-950">
        <code className={`language-${match ? match[1] : ''} text-sm text-slate-200`} {...props}>
          {children}
        </code>
      </pre>
    ) : (
      <code className="bg-slate-700 text-sky-300 px-1 py-0.5 rounded text-sm font-mono" {...props}>
        {children}
      </code>
    );
  },
  a: ({node, ...props}) => <a className="text-sky-400 hover:text-sky-300 underline focus:outline-none focus:ring-1 focus:ring-sky-400 rounded" target="_blank" rel="noopener noreferrer" {...props} />,
  strong: ({node, ...props}) => <strong className="font-semibold text-slate-100" {...props} />,
  em: ({node, ...props}) => <em className="italic text-slate-200" {...props} />,
  hr: ({node, ...props}) => <hr className="my-3 border-slate-700" {...props} />,
  table: ({node, ...props}) => <table className="table-auto w-full my-2 border border-slate-700 text-slate-200" {...props} />,
  thead: ({node, ...props}) => <thead className="bg-slate-700" {...props} />, 
  th: ({node, ...props}) => <th className="border border-slate-600 px-2 py-1 text-left text-slate-100" {...props} />,
  td: ({node, ...props}) => <td className="border border-slate-600 px-2 py-1" {...props} />,
};


export const MessageDisplay: React.FC<MessageDisplayProps> = ({ 
    message, 
    isLastMessage,
    onRegenerate, 
    onEdit,
    isAiResponding
}) => {
  const [copied, setCopied] = useState(false);
  const isUser = message.sender === MessageSender.USER;
  const alignment = isUser ? 'justify-end' : 'justify-start';
  const bubbleBgColor = isUser ? 'bg-cyan-700' : 'bg-slate-800';
  const textColor = isUser ? 'text-white' : 'text-slate-100'; 
  const iconContainerColor = isUser ? 'text-cyan-100' : 'text-sky-400'; 

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(message.text);
      setCopied(true);
    } catch (err) {
      console.error('Failed to copy text: ', err);
    }
  };

  useEffect(() => {
    if (copied) {
      const timer = setTimeout(() => setCopied(false), 2000);
      return () => clearTimeout(timer);
    }
  }, [copied]);

  const renderMessageContent = () => {
    if (message.isLoading && message.text === '') {
      return (
        <div className="flex items-center space-x-1 py-1 text-slate-400 text-sm">
          <span>Brain1 is typing</span>
          <span className="animate-pulse text-sky-400 ml-1 text-lg">•</span>
          <span className="animate-pulse text-sky-400 text-lg [animation-delay:0.15s]"> •</span>
          <span className="animate-pulse text-sky-400 text-lg [animation-delay:0.3s]"> •</span>
        </div>
      );
    }
    if (!isUser) {
      return (
        <ReactMarkdown remarkPlugins={[remarkGfm]} components={markdownComponents}>
          {message.text}
        </ReactMarkdown>
      );
    }
    return <div className={`whitespace-pre-line break-words ${isUser ? 'text-white' : 'text-slate-100'}`}>{message.text}</div>;
  };
  
  const canEdit = isUser && !isAiResponding; // Allow editing any user message if AI is not busy globally
  const canRegenerate = !isUser && !message.isLoading && isLastMessage && !isAiResponding; // Only last AI message of the chat

  return (
    <div className={`flex ${alignment} group relative animate-fadeInSlideUp`}>
      <div className={`max-w-xl lg:max-w-2xl px-4 py-3 rounded-lg shadow-md ${bubbleBgColor} ${textColor}`}>
        <div className="flex items-start space-x-3">
          <div className={`flex-shrink-0 mt-1 ${iconContainerColor}`}>
            {isUser ? <UserIcon className="w-5 h-5" /> : <BrainIcon className="w-5 h-5 stroke-current" />} 
          </div>
          <div className="flex-grow min-w-[30px]"> 
            {renderMessageContent()}
          </div>
        </div>
        <div className="flex justify-end items-center mt-1.5 space-x-2">
          {canEdit && (
            <button
                onClick={onEdit}
                className={`p-1 rounded-md ${isUser ? 'text-cyan-100 hover:bg-cyan-600' : 'text-slate-400 hover:bg-slate-700'} opacity-0 group-hover:opacity-100 focus:opacity-100 transition-all duration-200 focus:outline-none focus:ring-1 ${isUser ? 'focus:ring-cyan-200' : 'focus:ring-slate-400'} hover:scale-110 focus:scale-110 active:scale-100`}
                aria-label="Edit message"
                title="Edit"
                disabled={isAiResponding}
            >
                <PencilIcon className="w-3.5 h-3.5" />
            </button>
          )}
          {canRegenerate && (
             <button
                onClick={onRegenerate}
                className={`p-1 rounded-md ${isUser ? 'text-cyan-100 hover:bg-cyan-600' : 'text-slate-400 hover:bg-slate-700'} opacity-0 group-hover:opacity-100 focus:opacity-100 transition-all duration-200 focus:outline-none focus:ring-1 ${isUser ? 'focus:ring-cyan-200' : 'focus:ring-slate-400'} hover:scale-110 focus:scale-110 active:scale-100`}
                aria-label="Regenerate response"
                title="Regenerate"
                disabled={isAiResponding}
              >
                <RefreshIcon className="w-3.5 h-3.5" />
              </button>
          )}
          {!message.isLoading && (
             <button
                onClick={handleCopy}
                className={`p-1 rounded-md ${isUser ? 'text-cyan-100 hover:bg-cyan-600' : 'text-slate-400 hover:bg-slate-700'} opacity-0 group-hover:opacity-100 focus:opacity-100 transition-all duration-200 focus:outline-none focus:ring-1 ${isUser ? 'focus:ring-cyan-200' : 'focus:ring-slate-400'} hover:scale-110 focus:scale-110 active:scale-100`}
                aria-label={copied ? "Copied to clipboard" : "Copy message to clipboard"}
                title={copied ? "Copied!" : "Copy"}
              >
                {copied ? <CheckIcon className="w-3.5 h-3.5 animate-scaleIn" /> : <CopyIcon className="w-3.5 h-3.5" />}
              </button>
          )}
          {!message.isLoading && (
             <div className={`text-xs ${isUser ? 'text-cyan-200' : 'text-slate-400'} opacity-0 group-hover:opacity-100 focus-within:opacity-100 transition-opacity duration-200`}>
                {new Date(message.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
             </div>
          )}
        </div>
      </div>
    </div>
  );
};
