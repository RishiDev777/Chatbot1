
import React, { useState } from 'react';
import { ChatSession } from '../types';
import { TrashIcon } from './icons/TrashIcon';
import { ChatBubbleIcon } from './icons/ChatBubbleIcon'; // Icon for conversation
import { formatDistanceToNowStrict } from 'date-fns';


interface ConversationItemProps {
  session: ChatSession;
  isSelected: boolean;
  onSelect: () => void;
  onDelete: () => void;
}

export const ConversationItem: React.FC<ConversationItemProps> = ({
  session,
  isSelected,
  onSelect,
  onDelete,
}) => {
  const [isHovered, setIsHovered] = useState(false);

  const handleDeleteClick = (e: React.MouseEvent) => {
    e.stopPropagation(); // Prevent onSelect from firing
    onDelete();
  };

  let relativeTime = '';
  try {
    relativeTime = formatDistanceToNowStrict(new Date(session.lastUpdatedAt), { addSuffix: true });
  } catch (error) {
    console.warn("Error formatting date for session:", session.id, error);
    relativeTime = new Date(session.lastUpdatedAt).toLocaleDateString(); // Fallback
  }


  return (
    <button
      onClick={onSelect}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      className={`w-full flex items-center justify-between p-2.5 rounded-lg text-left transition-colors duration-150 focus:outline-none group
        ${
          isSelected
            ? 'bg-sky-700 text-white shadow-md'
            : 'text-slate-300 hover:bg-slate-800 focus:bg-slate-700'
        }`}
      aria-current={isSelected ? 'page' : undefined}
    >
      <div className="flex items-center space-x-2 overflow-hidden">
        <ChatBubbleIcon className={`w-4 h-4 flex-shrink-0 ${isSelected ? 'text-sky-200' : 'text-sky-500'}`} />
        <div className="flex flex-col overflow-hidden">
            <span className="text-sm font-medium truncate">{session.title}</span>
            <span className={`text-xs truncate ${isSelected ? 'text-sky-300' : 'text-slate-500'}`}>{relativeTime}</span>
        </div>
      </div>
      {(isHovered || isSelected) && (
        <div
          onClick={handleDeleteClick}
          className={`p-1.5 rounded-md ${isSelected ? 'text-sky-200 hover:bg-sky-600' : 'text-slate-400 hover:text-red-500 hover:bg-slate-700'} transition-colors duration-150 opacity-0 group-hover:opacity-100 focus-within:opacity-100 ${isSelected && 'opacity-100'}`}
          aria-label="Delete chat session"
          role="button" // Make it behave like a button for accessibility
          tabIndex={0} // Make it focusable
          onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') handleDeleteClick(e as any); }}
        >
          <TrashIcon className="w-4 h-4" />
        </div>
      )}
    </button>
  );
};
