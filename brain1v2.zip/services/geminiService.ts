
import { GoogleGenAI, Chat, Content } from "@google/genai"; // Correct imports
import { ChatMessage, MessageRole } from '../types'; // Import necessary types

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  console.error("CRITICAL: API_KEY environment variable not set. Gemini service cannot be initialized.");
}

let ai: GoogleGenAI | null = null;
if (API_KEY) {
  ai = new GoogleGenAI({ apiKey: API_KEY });
}

// Helper to convert ChatMessage[] to Gemini's Content[] history format
const formatHistoryForGemini = (messages: ChatMessage[]): Content[] => {
  return messages.map(msg => ({
    role: msg.sender === 'USER' ? MessageRole.USER : MessageRole.MODEL,
    parts: [{ text: msg.text }],
  })).filter(content => content.parts[0].text.trim() !== ''); // Filter out empty messages for history
};

const defaultSystemInstruction = 'You are Brain1, a sophisticated and insightful AI assistant. Provide clear, well-structured answers. You MUST use standard Markdown for formatting when appropriate (e.g., for headings, lists, bold, italics, code blocks, tables, links). Use actual newline characters (\\n) for paragraph breaks within your Markdown content.';

const startChat = (history?: ChatMessage[], systemInstructionOverride?: string): Chat => {
  if (!ai) {
    throw new Error("Gemini AI client not initialized. API_KEY might be missing.");
  }
  
  const geminiHistory: Content[] = history ? formatHistoryForGemini(history) : [];
  const activeSystemInstruction = systemInstructionOverride && systemInstructionOverride.trim() !== "" 
    ? systemInstructionOverride 
    : defaultSystemInstruction;

  const chat = ai.chats.create({
    model: 'gemini-2.5-flash-preview-04-17',
    history: geminiHistory, 
    config: {
      systemInstruction: activeSystemInstruction,
    }
  });
  return chat;
};

export const geminiChatService = {
  startChat,
};
