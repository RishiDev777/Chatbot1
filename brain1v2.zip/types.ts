
export enum MessageSender {
  USER = 'USER',
  AI = 'AI',
}

// For Gemini API history
export enum MessageRole {
  USER = 'user',
  MODEL = 'model',
}

export interface ChatMessage {
  id: string;
  text: string;
  sender: MessageSender;
  timestamp: Date;
  isLoading?: boolean;
  role?: MessageRole; // Optional: to map to Gemini's expected role for history
}

export interface ChatSession {
  id: string;
  title: string;
  messages: ChatMessage[];
  createdAt: Date;
  lastUpdatedAt: Date;
  customSystemInstruction?: string; // Added for custom instructions per session
}