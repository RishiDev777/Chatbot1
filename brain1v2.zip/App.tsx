
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { ChatMessage, MessageSender, ChatSession, MessageRole } from './types';
import { ChatInput, EditState } from './components/ChatInput';
import { MessageDisplay } from './components/MessageDisplay';
import { geminiChatService } from './services/geminiService';
import { Chat } from '@google/genai';
import { BrainIcon } from './components/icons/BrainIcon';
import { TrashIcon } from './components/icons/TrashIcon';
import { Sidebar } from './components/Sidebar';
import { MenuIcon } from './components/icons/MenuIcon';
import { PencilIcon } from './components/icons/PencilIcon';
import { SaveIcon } from './components/icons/SaveIcon';
import { TuneIcon } from './components/icons/TuneIcon'; // New Icon

const BRAIN1_SESSIONS_KEY = 'brain1-allChatSessions';
const BRAIN1_CURRENT_SESSION_ID_KEY = 'brain1-currentSessionId';

const App: React.FC = () => {
  const [sessions, setSessions] = useState<ChatSession[]>([]);
  const [currentSessionId, setCurrentSessionId] = useState<string | null>(null);
  const [isAiResponding, setIsAiResponding] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [chatInstance, setChatInstance] = useState<Chat | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const stopGenerationRef = useRef<boolean>(false);
  const [editingState, setEditingState] = useState<EditState | null>(null);
  const [isSidebarOpen, setIsSidebarOpen] = useState<boolean>(true);

  const [isEditingTitle, setIsEditingTitle] = useState<boolean>(false);
  const [editingTitleText, setEditingTitleText] = useState<string>("");
  const [showCustomInstructionInput, setShowCustomInstructionInput] = useState<boolean>(false);
  const [customInstructionText, setCustomInstructionText] = useState<string>("");

  const currentSession = sessions.find(s => s.id === currentSessionId);

  const createNewSession = (messages: ChatMessage[] = []): ChatSession => {
    const newSessionId = crypto.randomUUID();
    const now = new Date();
    const defaultInitialMessage: ChatMessage = {
      id: crypto.randomUUID(),
      text: "Hello! I'm Brain1, your AI assistant. How can I help you today?",
      sender: MessageSender.AI,
      timestamp: now,
      role: MessageRole.MODEL,
    };
    return {
      id: newSessionId,
      title: "New Chat",
      messages: messages.length > 0 ? messages : [defaultInitialMessage],
      createdAt: now,
      lastUpdatedAt: now,
      customSystemInstruction: "", // Initialize with empty custom instruction
    };
  };
  
  useEffect(() => {
    try {
      const storedSessions = localStorage.getItem(BRAIN1_SESSIONS_KEY);
      let loadedSessions: ChatSession[] = [];
      if (storedSessions) {
        loadedSessions = JSON.parse(storedSessions).map((s: any) => ({
          ...s,
          createdAt: new Date(s.createdAt),
          lastUpdatedAt: new Date(s.lastUpdatedAt),
          customSystemInstruction: s.customSystemInstruction || "", // Ensure field exists
          messages: s.messages.map((msg: any) => ({
            ...msg,
            timestamp: new Date(msg.timestamp),
            isLoading: msg.isLoading === true ? false : undefined,
            text: (msg.isLoading === true && msg.text) ? `${msg.text}\n\n--- (Stream might have been interrupted previously)` : msg.text,
          })),
        }));
      }

      const storedCurrentSessionId = localStorage.getItem(BRAIN1_CURRENT_SESSION_ID_KEY);
      let activeSessionId = storedCurrentSessionId && loadedSessions.find(s => s.id === storedCurrentSessionId) ? storedCurrentSessionId : null;

      if (loadedSessions.length === 0) {
        const newSession = createNewSession();
        loadedSessions.push(newSession);
        activeSessionId = newSession.id;
      } else if (!activeSessionId && loadedSessions.length > 0) {
        activeSessionId = loadedSessions.sort((a,b) => new Date(b.lastUpdatedAt).getTime() - new Date(a.lastUpdatedAt).getTime())[0].id;
      }
      
      setSessions(loadedSessions);
      setCurrentSessionId(activeSessionId);

    } catch (e) {
      console.error("Failed to load sessions from local storage:", e);
      const newSession = createNewSession();
      setSessions([newSession]);
      setCurrentSessionId(newSession.id);
    }
  }, []);

  useEffect(() => {
    if (sessions.length > 0) {
      localStorage.setItem(BRAIN1_SESSIONS_KEY, JSON.stringify(sessions));
    }
    if (currentSessionId) {
      localStorage.setItem(BRAIN1_CURRENT_SESSION_ID_KEY, currentSessionId);
    }
  }, [sessions, currentSessionId]);

  useEffect(() => {
    if (!currentSessionId) return;
    const activeSession = sessions.find(s => s.id === currentSessionId);
    if (!activeSession) return;

    try {
      const historyForChatInstance = activeSession.messages.filter(m => !m.isLoading && m.text.trim() !== '');
      const chat = geminiChatService.startChat(historyForChatInstance, activeSession.customSystemInstruction);
      setChatInstance(chat);
      setError(null);
      // Update editing title and custom instruction text when session changes
      setEditingTitleText(activeSession.title);
      setCustomInstructionText(activeSession.customSystemInstruction || "");
      setIsEditingTitle(false); // Close title editing if session changes
      // setShowCustomInstructionInput(false); // Optionally close instruction input
    } catch (e: any) {
      console.error("Failed to initialize Gemini Chat for session:", currentSessionId, e);
      setError(`Failed to initialize AI: ${e.message}. API key configured?`);
      setChatInstance(null);
    }
  }, [currentSessionId, sessions]); 

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };
  
  const currentMessages = currentSession?.messages || [];
  useEffect(scrollToBottom, [currentMessages]);

  const updateCurrentSessionMessages = (updateFn: (prevMessages: ChatMessage[]) => ChatMessage[], newTimestamp?: boolean) => {
    setSessions(prevSessions =>
      prevSessions.map(s =>
        s.id === currentSessionId
          ? { ...s, messages: updateFn(s.messages), lastUpdatedAt: newTimestamp ? new Date() : s.lastUpdatedAt }
          : s
      )
    );
  };
  
  const autoUpdateSessionTitleIfNeeded = (sessionId: string, firstUserMessageText: string) => {
      const session = sessions.find(s => s.id === sessionId);
      // Only auto-title if it's the default "New Chat" and has very few messages (likely first turn)
      if (session && session.title === "New Chat" && session.messages.length <= 2) { 
          const newTitle = firstUserMessageText.substring(0, 30) + (firstUserMessageText.length > 30 ? "..." : "");
          setSessions(prevSessions => 
              prevSessions.map(s => s.id === sessionId ? {...s, title: newTitle, lastUpdatedAt: new Date()} : s)
          );
      }
  };

  const coreSendMessageLogic = useCallback(async (inputText: string, targetAiMessageIdToUpdate?: string) => {
    if (!chatInstance || !currentSessionId) {
      setError("AI chat service is not available or no session is active.");
      setIsAiResponding(false);
      return;
    }
    
    setIsAiResponding(true);
    setError(null);
    stopGenerationRef.current = false;

    const aiMessageId = targetAiMessageIdToUpdate || crypto.randomUUID();

    if (!targetAiMessageIdToUpdate) {
      updateCurrentSessionMessages(prevMessages => [
        ...prevMessages,
        {
          id: aiMessageId,
          text: '',
          sender: MessageSender.AI,
          timestamp: new Date(),
          isLoading: true,
          role: MessageRole.MODEL,
        },
      ]);
    } else {
       updateCurrentSessionMessages(prevMessages =>
        prevMessages.map(msg =>
          msg.id === aiMessageId ? { ...msg, text: '', isLoading: true, timestamp: new Date(), role: MessageRole.MODEL } : msg
        )
      );
    }

    let accumulatedText = "";
    try {
      const stream = await chatInstance.sendMessageStream({ message: inputText });
      for await (const chunk of stream) {
        if (stopGenerationRef.current) {
          accumulatedText += "\n\n--- Generation stopped by user ---";
          break;
        }
        const chunkText = chunk.text;
        if (chunkText) {
          accumulatedText += chunkText;
          updateCurrentSessionMessages(prevMessages =>
            prevMessages.map(msg =>
              msg.id === aiMessageId ? { ...msg, text: accumulatedText, isLoading: true } : msg
            )
          );
        }
      }
    } catch (e: any) {
      console.error("Error sending message to Gemini:", e);
      const err = e as Error;
      let errorMessageText = "An unexpected error occurred with the AI service.";
       if (e?.httpError?.status) {
         errorMessageText = `AI Service Error: ${e.httpError.status}. ${ e.httpError.message || (err?.message || "Details unavailable") }`;
      } else if (err?.message) {
          errorMessageText = err.message;
      }
      setError(`AI Error: ${errorMessageText}`);
      accumulatedText += `\n\n--- AI Error: ${errorMessageText} ---`;
    } finally {
      updateCurrentSessionMessages(prevMessages =>
        prevMessages.map(msg =>
          msg.id === aiMessageId ? { ...msg, text: accumulatedText, isLoading: false } : msg
        ), true
      );
      setIsAiResponding(false);
      stopGenerationRef.current = false;
    }
  }, [chatInstance, currentSessionId]);


  const handleSendOrUpdateMessage = useCallback(async (inputText: string) => {
    if (!inputText.trim() || isAiResponding || !currentSessionId) return;

    if (editingState) {
      const activeSession = sessions.find(s => s.id === currentSessionId);
      if (!activeSession) return;

      const userMessageIndex = activeSession.messages.findIndex(m => m.id === editingState.messageId);
      if (userMessageIndex === -1) {
        setEditingState(null); return;
      }
      
      const messagesUpToEdit = activeSession.messages.slice(0, userMessageIndex);
      const updatedUserMessage: ChatMessage = {
        ...activeSession.messages[userMessageIndex],
        text: inputText,
        timestamp: new Date(),
      };

      setSessions(prevSessions => prevSessions.map(s => 
          s.id === currentSessionId ? {
              ...s,
              messages: [...messagesUpToEdit, updatedUserMessage],
              lastUpdatedAt: new Date()
          } : s
      ));
      setEditingState(null);
      await coreSendMessageLogic(inputText);

    } else {
      const userMessage: ChatMessage = {
        id: crypto.randomUUID(),
        text: inputText,
        sender: MessageSender.USER,
        timestamp: new Date(),
        role: MessageRole.USER,
      };
      updateCurrentSessionMessages(prevMessages => [...prevMessages, userMessage], true);
      autoUpdateSessionTitleIfNeeded(currentSessionId, inputText);
      await coreSendMessageLogic(inputText);
    }
  }, [isAiResponding, coreSendMessageLogic, editingState, sessions, currentSessionId]);

  const handleStopGenerating = () => {
    stopGenerationRef.current = true;
  };

  const handleRegenerateResponse = useCallback(async (aiMessageId: string) => {
    if (isAiResponding || !chatInstance || !currentSessionId) return;
    const activeSession = sessions.find(s => s.id === currentSessionId);
    if (!activeSession) return;

    const aiMessageIndex = activeSession.messages.findIndex(msg => msg.id === aiMessageId);
    if (aiMessageIndex > 0 && activeSession.messages[aiMessageIndex - 1].sender === MessageSender.USER) {
      const userPromptText = activeSession.messages[aiMessageIndex - 1].text;
      await coreSendMessageLogic(userPromptText, aiMessageId);
    } else {
      setError("Could not find original user prompt to regenerate.");
    }
  }, [isAiResponding, sessions, coreSendMessageLogic, chatInstance, currentSessionId]);
  
  const handleEditRequest = (message: ChatMessage) => {
    if (message.sender === MessageSender.USER) {
      setEditingState({ messageId: message.id, currentText: message.text });
    }
  };

  const handleCancelEdit = () => {
    setEditingState(null);
  };

  const handleClearChat = () => { 
    if (!currentSessionId) return;
    if (window.confirm("Clear messages in current chat? Cannot be undone.")) {
        const now = new Date();
        const defaultInitialMessage: ChatMessage = {
            id: crypto.randomUUID(),
            text: "Hello! I'm Brain1. How can I help?",
            sender: MessageSender.AI,
            timestamp: now,
            role: MessageRole.MODEL
        };
      setSessions(prev => prev.map(s => s.id === currentSessionId ? {...s, messages: [defaultInitialMessage], lastUpdatedAt: now } : s));
      setEditingState(null);
    }
  };

  const handleStartNewChat = () => {
    const newSession = createNewSession();
    setSessions(prev => [...prev, newSession]);
    setCurrentSessionId(newSession.id);
    setShowCustomInstructionInput(false);
    setIsSidebarOpen(false);
  };

  const handleSelectChat = (sessionId: string) => {
    setCurrentSessionId(sessionId);
    const selectedSession = sessions.find(s => s.id === sessionId);
    if (selectedSession) {
        setCustomInstructionText(selectedSession.customSystemInstruction || "");
        setEditingTitleText(selectedSession.title);
    }
    setIsEditingTitle(false);
    setShowCustomInstructionInput(false);
    setIsSidebarOpen(false);
  };

  const handleDeleteChat = (sessionIdToDelete: string) => {
    if (window.confirm("Delete chat session? Cannot be undone.")) {
      const remainingSessions = sessions.filter(s => s.id !== sessionIdToDelete);
      setSessions(remainingSessions);
      if (currentSessionId === sessionIdToDelete) {
        if (remainingSessions.length > 0) {
          setCurrentSessionId(remainingSessions.sort((a,b) => new Date(b.lastUpdatedAt).getTime() - new Date(a.lastUpdatedAt).getTime())[0].id);
        } else {
          handleStartNewChat(); 
        }
      }
    }
  };

  const toggleSidebar = () => setIsSidebarOpen(!isSidebarOpen);

  const handleToggleEditTitle = () => {
    if (currentSession) {
        setEditingTitleText(currentSession.title);
        setIsEditingTitle(!isEditingTitle);
    }
  };

  const handleSaveTitle = () => {
    if (currentSessionId && editingTitleText.trim()) {
      setSessions(prev => prev.map(s => 
        s.id === currentSessionId ? {...s, title: editingTitleText.trim(), lastUpdatedAt: new Date()} : s
      ));
      setIsEditingTitle(false);
    }
  };
  
  const handleSaveCustomInstruction = () => {
    if (currentSessionId) {
        setSessions(prev => prev.map(s => 
            s.id === currentSessionId ? {...s, customSystemInstruction: customInstructionText, lastUpdatedAt: new Date()} : s
        ));
        // setShowCustomInstructionInput(false); // Keep it open or close based on preference
        // Re-initialize chat instance with new system instruction is handled by useEffect on sessions
        alert("Custom instruction saved for this session.");
    }
  };


  return (
    <div className="flex h-screen bg-slate-950 overflow-hidden">
      <Sidebar
        sessions={sessions}
        currentSessionId={currentSessionId}
        onNewChat={handleStartNewChat}
        onSelectChat={handleSelectChat}
        onDeleteChat={handleDeleteChat}
        isOpen={isSidebarOpen}
        toggleSidebar={toggleSidebar}
      />
      <div className={`flex flex-col flex-grow h-screen max-w-full md:max-w-none bg-slate-950 shadow-2xl transition-all duration-300 ease-in-out ${isSidebarOpen ? 'md:ml-72' : 'ml-0'}`}>
         <header className="bg-slate-900 p-3 sm:p-4 shadow-md border-b border-slate-800 flex items-center justify-between animate-fadeIn relative" style={{ animationDelay: '0.1s' }}>
            <div className="flex items-center space-x-2 flex-grow min-w-0">
                <button onClick={toggleSidebar} className="p-2 text-slate-400 hover:text-sky-400 md:hidden rounded-md" aria-label="Toggle sidebar">
                    <MenuIcon className="w-6 h-6" />
                </button>
                <BrainIcon className="w-7 h-7 text-sky-400 animate-fadeIn flex-shrink-0" style={{ animationDelay: '0.2s' }} />
                
                {isEditingTitle && currentSession ? (
                    <div className="flex items-center space-x-2 flex-grow min-w-0">
                        <input 
                            type="text"
                            value={editingTitleText}
                            onChange={(e) => setEditingTitleText(e.target.value)}
                            onKeyDown={(e) => e.key === 'Enter' && handleSaveTitle()}
                            className="text-xl sm:text-2xl font-semibold text-sky-400 bg-slate-800 border border-sky-600 rounded-md px-2 py-0.5 flex-grow min-w-[100px]"
                            autoFocus
                        />
                        <button onClick={handleSaveTitle} className="p-1.5 text-sky-400 hover:text-sky-300 rounded-md" aria-label="Save title"><SaveIcon className="w-5 h-5"/></button>
                        <button onClick={() => setIsEditingTitle(false)} className="p-1.5 text-slate-400 hover:text-slate-300 rounded-md" aria-label="Cancel edit title">Cancel</button>
                    </div>
                ) : (
                    <h1 onClick={handleToggleEditTitle} className="text-xl sm:text-2xl font-semibold text-sky-400 animate-fadeIn truncate cursor-pointer hover:opacity-80" style={{ animationDelay: '0.3s' }} title="Edit title">
                        {currentSession?.title || "Brain1"}
                    </h1>
                )}
                 {!isEditingTitle && currentSession && (
                     <button onClick={handleToggleEditTitle} className="p-1 text-slate-400 hover:text-sky-400 rounded-md ml-2 flex-shrink-0" aria-label="Edit chat title">
                        <PencilIcon className="w-4 h-4"/>
                    </button>
                 )}
            </div>

            <div className="flex items-center space-x-1 sm:space-x-2 flex-shrink-0">
                {currentSession && (
                    <button 
                        onClick={() => setShowCustomInstructionInput(!showCustomInstructionInput)}
                        className="p-2 text-slate-400 hover:text-sky-400 focus:outline-none focus:ring-2 focus:ring-sky-500 rounded-md transition-transform duration-150 ease-in-out hover:scale-110 focus:scale-110 active:scale-100"
                        aria-label="Custom instructions"
                        title="Custom Instructions"
                    >
                        <TuneIcon className="w-5 h-5" />
                    </button>
                )}
                <button
                    onClick={handleClearChat}
                    className="p-2 text-slate-400 hover:text-sky-400 focus:outline-none focus:ring-2 focus:ring-sky-500 rounded-md transition-transform duration-150 ease-in-out hover:scale-110 focus:scale-110 active:scale-100"
                    aria-label="Clear current chat history"
                    title="Clear current chat"
                >
                    <TrashIcon className="w-5 h-5" />
                </button>
            </div>
        </header>
        
        {showCustomInstructionInput && currentSession && (
            <div className="p-3 bg-slate-800 border-b border-slate-700 animate-fadeInSlideUp">
                <label htmlFor="customInstruction" className="block text-sm font-medium text-sky-300 mb-1">Custom System Instruction for this Chat:</label>
                <textarea
                    id="customInstruction"
                    value={customInstructionText}
                    onChange={(e) => setCustomInstructionText(e.target.value)}
                    placeholder="e.g., Act as a pirate. / Explain things very simply."
                    rows={3}
                    className="w-full p-2 bg-slate-700 text-slate-100 border border-slate-600 rounded-md focus:ring-1 focus:ring-sky-500 focus:border-sky-500 scrollbar-thin scrollbar-thumb-sky-600 scrollbar-track-slate-800"
                />
                <button 
                    onClick={handleSaveCustomInstruction}
                    className="mt-2 px-3 py-1.5 bg-sky-600 text-white text-sm rounded-md hover:bg-sky-500 focus:outline-none focus:ring-2 focus:ring-sky-500"
                >
                    Save Instruction
                </button>
            </div>
        )}
        
        {error && (
          <div className="p-3 bg-red-700 text-red-100 text-center text-sm animate-fadeInSlideUp" role="alert">
            <p>{error}</p>
          </div>
        )}

        <div className="flex-grow p-4 sm:p-6 space-y-4 overflow-y-auto bg-slate-900 scrollbar-thin scrollbar-thumb-sky-600 scrollbar-track-slate-900">
          {currentMessages.map((msg, index) => (
            <MessageDisplay 
              key={msg.id} 
              message={msg}
              isLastMessage={index === currentMessages.length - 1}
              onRegenerate={() => handleRegenerateResponse(msg.id)}
              onEdit={() => handleEditRequest(msg)}
              isAiResponding={isAiResponding}
            />
          ))}
          <div ref={messagesEndRef} />
        </div>
        
        <div className="p-2 sm:p-4 bg-slate-900 border-t border-slate-800">
          <ChatInput 
            onSendMessage={handleSendOrUpdateMessage} 
            isLoading={isAiResponding}
            onStopGenerating={handleStopGenerating}
            editingState={editingState}
            onCancelEdit={handleCancelEdit}
          />
        </div>
      </div>
    </div>
  );
};

export default App;
